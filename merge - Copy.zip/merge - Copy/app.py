from flask import Flask, render_template, session, redirect
from functools import wraps
import pymongo

app = Flask(__name__)
app.secret_key = b'\xcc^\x91\xea\x17-\xd0W\x03\xa7\xf8J0\xac8\xc5'

# Database
client= pymongo.MongoClient('localhost', 27017)
db = client.user_login_system

# Decorators
def login_required(f):
  @wraps(f)
  def wrap(*args,**kwargs):
    if 'logged_in' in session:
      return f(*args, **kwargs)
    else:
      return redirect('/')
  
  return wrap

# Routes
from user import routes

@app.route('/')
def index():
  return render_template('index.html')


@app.route('/about/')
def about():
  return render_template('about.html')
  

@app.route('/job-list/')
def joblist():
  return render_template('job-list.html')

@app.route('/job-detail/')
def jobdetail():
  return render_template('job-detail.html')

@app.route('/category/')
def category():
  return render_template('category.html')

@app.route('/404/')
def defalut():
  return render_template('404.html')

@app.route('/testimonial/')
def testimonial():
  return render_template('testimonial.html')


@app.route('/contact/')
def contact():
  return render_template('contact.html')

@app.route('/home/')
def home():
  return render_template('home.html')

@app.route('/base/')
def base ():
  return render_template('base.html')


@app.route('/dashboard/')
@login_required
def dashboard():
  return render_template('dashboard.html')



if __name__=="__main__":
   app.run(debug=True,port=5000)
 